package be.ing.fundtransfer.service.impl;



import be.ing.fundtransfer.bean.UserData;
import be.ing.fundtransfer.dao.UserDAO;

import be.ing.fundtransfer.dao.UserDetailsDAO;
import be.ing.fundtransfer.data.User;
import be.ing.fundtransfer.data.UserDetails;
import be.ing.fundtransfer.exception.DataInsertionException;
import be.ing.fundtransfer.exception.DataRetrievalException;
import be.ing.fundtransfer.util.Constants;
import be.ing.fundtransfer.service.UserService;
import be.ing.fundtransfer.util.UserDaoWraper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserDAO userDAO;
    @Autowired
    UserDetailsDAO userDetailsDAO;


    @Override
    public String createUser(UserData userData) throws DataInsertionException{
        try {
            userDAO.createUser(UserDaoWraper.convertUserDataToUser(userData));
            userDetailsDAO.createUserdDetails(UserDaoWraper.convertUserDataToUserDetails(userData));
            return Constants.SUCCESS;
        }catch(Exception ex) {
            throw new DataInsertionException(ex.getLocalizedMessage());
        }
    }
    @Override
    public UserData getByUserName(String userName)throws DataRetrievalException {
        try {
             User user = userDAO.getUserByUserName(userName);
             UserDetails userDetails =userDetailsDAO.getUserByUserDetailsName(user.getUserName());
              return UserDaoWraper.convertUserAndUserDetailsToUserData(user, userDetails);
        }catch(Exception ex) {
            throw new DataRetrievalException(ex.getLocalizedMessage());
        }
    }

    @Override
    public UserData getByUserEmail(String email) throws DataRetrievalException{
        try {
            User user = userDAO.getUserByEmail(email);
            UserDetails userDetails =userDetailsDAO.getUserByUserDetailsName(user.getUserName());


            return UserDaoWraper.convertUserAndUserDetailsToUserData(user, userDetails);
        }catch(Exception ex) {
            throw new DataRetrievalException(ex.getLocalizedMessage());
        }
    }

    @Override
    public String updateUser(UserData user) {
        return null;
    }

    @Override
    public String deleteUser(UserData user) {
        return null;
    }

    @Override
    public List<UserData> findAllUsers() throws DataRetrievalException{
        List<User> users = userDAO.findAllUsers();
        return null;
    }
}
