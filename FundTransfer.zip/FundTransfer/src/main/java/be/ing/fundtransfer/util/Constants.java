package be.ing.fundtransfer.util;

public class Constants {
    public static String SUCCESS ="SUCCESS";
    public static String FAILED ="FAILED";
    public static final String TWILIO_ACCNT_NUMBER = "AC45fdb73000d50d02626c8a5fefa2e943";
    public static final String AUTH_TOKEN = "e73ff04f2679a2002eb35d78c052a1cc";
    public static final String TWILIO_MOB_NUMBER = "+19097871722";
    public static final String OTP_STATUS_SUCCESS="OTP_STATUS_SUCCESS";
    public static final String BLANK=" ";
}
