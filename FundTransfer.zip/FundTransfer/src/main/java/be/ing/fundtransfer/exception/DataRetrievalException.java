package be.ing.fundtransfer.exception;

public class DataRetrievalException extends  Exception{
    public DataRetrievalException(String msg)
    {
        // Call constructor of parent Exception
        super(msg);
    }
}
